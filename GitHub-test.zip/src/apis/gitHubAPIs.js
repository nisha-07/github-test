export const getAllGitHubUser = "https://api.github.com/users"

export const getUserInfo = "http://api.github.com/users/"