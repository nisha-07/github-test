const KeyValue = ({key, value}) => {
	return (
		<div>
			{key}: <span>{value}</span> 
		</div>
	)
}

export default KeyValue
