import classes from "./Header.module.scss";

const Header = () => {
	return (
		<div className={classes.header}>
			GitHub Information
		</div>
	)
}

export default Header
